#include <stdio.h>
#include <stdlib.h>

int main()
{

    int ch=menu();
    if(ch==1)
    {
        gk();
    }
    else if(ch==2)
    {
        math();
    }
    else if(ch==3)
    {
        c_prog();
    }
    else if(ch==0)
    {
        printf("\nThanks....!!");
        system("exit");
    }
    else if(ch==5)
    {
        details();
    }
    return 0;
}


int menu()
{
    int ch;
    printf("Choose any of the Topic(s):\n");
    printf("1.General Knowledge\n");
    printf("2.Mathematics\n");
    printf("3.C Programming\n");
    printf("\n5.Rules");
    printf("\n0.Exit\n");

    printf("Choice:");
    scanf("%d", &ch);
    if((ch>= 0 && ch<=3)|| (ch==5))
    {
        return ch;
    }
    else
    {
        printf("Invalid Choice..!!\n\n");
        system("pause");
        system("cls");
        main();
    }
}


void gk()
{

    int ch,m=0;

    printf("\nTopic: General Knowledge\nLet's Start\n");
    system("pause");
    system("cls");
    ///1
    printf("1) What is the National Game of England?\n");
    printf("\t1.Baseball\n");
    printf("\t2.Cricket\n");
    printf("\t3.Football\n");
    printf("\t4.Rugby\n");
    printf("Choose:");
    scanf("%d", &ch);

    if(ch>4 || ch<1)
    {
        printf("Wrong Input..!!\nChoose:");
        scanf("%d", &ch);

        if(ch==2)
        {
            printf("Correct Answer");
            m= m +10;
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is Cricket");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }

    else
    {
        if(ch==2)
        {
            printf("Correct Answer");
            m= m +10;
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is Cricket");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }


    ///2
    printf("2) What is the Study of Earthquake called?\n");
    printf("\t1.Etimology\n");
    printf("\t2.Zoology\n");
    printf("\t3.Orology\n");
    printf("\t4.Seismology\n");
    printf("Choose:");
    scanf("%d", &ch);

    if(ch>4 || ch<1)
    {
        printf("Wrong Input..!!\nChoose:");
        scanf("%d", &ch);

        if(ch==4)
        {
            m= m +10;
            printf("Correct Answer");
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is Seismology");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }

    else
    {
        if(ch==4)
        {
            m= m +10;
            printf("Correct Answer");
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is Seismology");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }


    ///3


    printf("3) What is the Longest River in Bangladesh?\n");
    printf("\t1.Karnaphuli\n");
    printf("\t2.Meghna\n");
    printf("\t3.Atrai\n");
    printf("\t4.Brahmaputra\n");
    printf("Choose:");
    scanf("%d", &ch);


    if(ch>4 || ch<1)
    {
        printf("Wrong Input..!!\nChoose:");
        scanf("%d", &ch);



        if(ch==4)
        {
            m= m +10;
            printf("Correct Answer");
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is Brahmaputra");
        }

        printf("\nYou Current Score is %d\n", m);

        system("pause");
        system("cls");

    }

    else
    {
        if(ch==4)
        {
            m= m +10;
            printf("Correct Answer");
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is Brahmaputra");
        }

        printf("\nYou Current Score is %d\n", m);

        system("pause");
        system("cls");
    }


    ///4
    printf("4) Who gave the Laws of Electromagnetic Induction?\n");
    printf("\t1.Coulomb\n");
    printf("\t2.Faraday\n");
    printf("\t3.Maxwell\n");
    printf("\t4.Tesla\n");
    printf("Choose:");
    scanf("%d", &ch);

    if(ch>4 || ch<1)
    {
        printf("Wrong Input..!!\nChoose:");
        scanf("%d", &ch);


        if(ch==1)
        {
            m= m +10;
            printf("Correct Answer");
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is Coulomb");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }



    else
    {

        if(ch==1)
        {
            m= m +10;
            printf("Correct Answer");
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is Coulomb");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }

    ///5
    printf("5) What is the World's Largest Island?\n");
    printf("\t1.Finland\n");
    printf("\t2.Iceland\n");
    printf("\t3.Greenland\n");
    printf("\t4.Easter Island\n");
    printf("Choose:");
    scanf("%d", &ch);


    if(ch>4 || ch<1)
    {
        printf("Wrong Input..!!\nChoose:");
        scanf("%d", &ch);



        if(ch==3)
        {
            m= m +10;
            printf("Correct Answer");
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is Greenland");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }



    else
    {
        if(ch==3)
        {
            m= m +10;
            printf("Correct Answer");
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is Greenland");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }



    ///6
    printf("6) What is the World's Smallest Country?\n");
    printf("\t1.Monaco\n");
    printf("\t2.Vetican\n");
    printf("\t3.Morocco\n");
    printf("\t4.Tuvalu\n");
    printf("Choose:");
    scanf("%d", &ch);

    if(ch>4 || ch<1)
    {
        printf("Wrong Input..!!\nChoose:");
        scanf("%d", &ch);

        if(ch==2)
        {
            m= m +10;
            printf("Correct Answer");
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is Vetican");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }



    else
    {
        if(ch==2)
        {
            m= m +10;
            printf("Correct Answer");
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is Vetican");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }




    ///7
    printf("7) First Bangladeshi Woman to climb mount everest?\n");
    printf("\t1.Najma Khanum\n");
    printf("\t2.Nila Parveen\n");
    printf("\t3.Nishat Mazumder\n");
    printf("\t4.Nusrat Jahan\n");
    printf("Choose:");
    scanf("%d", &ch);

    if(ch>4 || ch<1)
    {
        printf("Wrong Input..!!\nChoose:");
        scanf("%d", &ch);

        if(ch==3)
        {
            m= m +10;
            printf("Correct Answer");
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is Nishat Mazumder");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }

    else
    {
        if(ch==3)
        {
            m= m +10;
            printf("Correct Answer");
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is Nishat Mazumder");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }

    ///8

    printf("8) What is the unit of Power?\n");
    printf("\t1.Newtons\n");
    printf("\t2.Coulombs\n");
    printf("\t3.Degrees\n");
    printf("\t4.Watt\n");
    printf("Choose:");
    scanf("%d", &ch);

    if(ch>4 || ch<1)
    {
        printf("Wrong Input..!!\nChoose:");
        scanf("%d", &ch);

        if(ch==4)
        {
            m= m +10;
            printf("Correct Answer");
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is Watt");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }
    else
    {
        if(ch==4)
        {
            m= m +10;
            printf("Correct Answer");
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is Watt");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }

    ///9
    printf("9) World's Smallest Ocean?\n");
    printf("\t1.Arctic Ocean\n");
    printf("\t2.Atlantic Ocean\n");
    printf("\t3.Pacific Ocean\n");
    printf("\t4.Indian Ocean\n");
    printf("Choose:");
    scanf("%d", &ch);
    if(ch>4 || ch<1)
    {
        printf("Wrong Input..!!\nChoose:");
        scanf("%d", &ch);
        if(ch==1)
        {
            m= m +10;
            printf("Correct Answer");
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is Arctic Ocean");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }


    else
    {
        if(ch==1)
        {
            m= m +10;
            printf("Correct Answer");
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is Arctic Ocean");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }
    ///10
    printf("10) Who Discovered America?\n");
    printf("\t1.Vasco da Gama\n");
    printf("\t2.Diego Columbus\n");
    printf("\t3.Christopher Columbus\n");
    printf("\t4.Amerigo Vespucci\n");
    printf("Choose:");
    scanf("%d", &ch);

    if(ch>4 || ch<1)
    {
        printf("Wrong Input..!!\nChoose:");
        scanf("%d", &ch);


        if(ch==3)
        {
            m= m +10;
            printf("Correct Answer");
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is Christopher Columbus");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }


    else
    {
        if(ch==3)
        {
            m= m +10;
            printf("Correct Answer");
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is Christopher Columbus");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }

    if(m==100)
    {
        printf("Your Score is %d\nCongrates.\nYou got full Marks\n",m);
        printf("Report: Excellent");
    }
    else if(m>=80 && m<=99)
    {
        printf("Your Score is %d\nReport: Very Good",m);
    }

    else if(m>=70 && m<=79)
    {
        printf("Your Score is %d\nReport: Good",m);
    }
    else if(m>=55 && m<=69)
    {
        printf("Your Score is %d\nReport: Average Marks\nTry better Next Time",m);
    }
    else if(m<55)
    {
        printf("Your Score is %d\nYou Failed\nTry Again",m);
    }




    printf("\n");
    system("pause");
    system("cls");

    main();
}


void math()
{
    int ch,m=0;

    printf("\nTopic: Mathematics\nLet's Start\n");
    system("pause");
    system("cls");
    ///1
    printf("1) If A={1,3,7} and B={1,4,3,9}, then A U B=______?\n");
    printf("\t1.{}\n");
    printf("\t2.{1,3}\n");
    printf("\t3.{1,3,5,7}\n");
    printf("\t4.{1,3,4,7,9}\n");
    printf("Choose:");
    scanf("%d", &ch);


    if(ch>4 || ch<1)
    {
        printf("Wrong Input..!!\nChoose:");
        scanf("%d", &ch);

        if(ch==4)
        {
            printf("Correct Answer");
            m= m +10;
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is {1,3,4,7,9}");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }
    else
    {
        if(ch==4)
        {
            printf("Correct Answer");
            m= m +10;
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is {1,3,4,7,9}");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }
    ///2
    printf("2) The Symbol 'U' means?\n");
    printf("\t1.Intersection\n");
    printf("\t2.Universal\n");
    printf("\t3.Nothing\n");
    printf("\t4.Set\n");
    printf("Choose:");
    scanf("%d", &ch);
    if(ch>4 || ch<1)
    {
        printf("Wrong Input..!!\nChoose:");
        scanf("%d", &ch);
        if(ch==2)
        {
            printf("Correct Answer");
            m= m +10;
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is Universal");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }

    else
    {
        if(ch==2)
        {
            printf("Correct Answer");
            m= m +10;
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is Universal");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }
    ///3
    printf("3) The Sum of three angles of a Triangle is?\n");
    printf("\t1.90\n");
    printf("\t2.160\n");
    printf("\t3.180\n");
    printf("\t4.360\n");
    printf("Choose:");
    scanf("%d", &ch);
    if(ch>4 || ch<1)
    {
        printf("Wrong Input..!!\nChoose:");
        scanf("%d", &ch);
        if(ch==3)
        {
            printf("Correct Answer");
            m= m +10;
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is 3");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }
    else
    {
        if(ch==3)
        {
            printf("Correct Answer");
            m= m +10;
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is 3");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }
    ///4
    printf("4) x^2 + 8x = -16. Find x?\n");
    printf("\t1.-4\n");
    printf("\t2.3\n");
    printf("\t3.-2\n");
    printf("\t4.+2\n");
    printf("Choose:");
    scanf("%d", &ch);
    if(ch>4 || ch<1)
    {
        printf("Wrong Input..!!\nChoose:");
        scanf("%d", &ch);
        if(ch==4 || ch==3)
        {
            printf("Correct Answer");
            m= m +10;
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is +2 or -2");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }
    else
    {
        if(ch==4 || ch==3)
        {
            printf("Correct Answer");
            m= m +10;
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is +2 or -2");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }
    ///5
    printf("5) 5005 - 5000 / 10.00=?\n");
    printf("\t1.4505\n");
    printf("\t2.5000\n");
    printf("\t3.0.5\n");
    printf("\t4.5405\n");
    printf("Choose:");
    scanf("%d", &ch);
    if(ch>4 || ch<1)
    {
        printf("Wrong Input..!!\nChoose:");
        scanf("%d", &ch);
        if(ch==1)
        {
            printf("Correct Answer");
            m= m +10;
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is 4505");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }
    else
    {
        if(ch==1)
        {
            printf("Correct Answer");
            m= m +10;
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is 4505");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }
    ///6

    printf("6) x = 3 is the solution of the question 3x^2 + (k-1)x + 9 = 0. Find k?\n");
    printf("\t1.13\n");
    printf("\t2.-11\n");
    printf("\t3.14\n");
    printf("\t4.11\n");
    printf("Choose:");
    scanf("%d", &ch);
    if(ch>4 || ch<1)
    {
        printf("Wrong Input..!!\nChoose:");
        scanf("%d", &ch);
        if(ch==2)
        {
            printf("Correct Answer");
            m= m +10;
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is -11");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }
    else
    {
        if(ch==2)
        {
            printf("Correct Answer");
            m= m +10;
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is -11");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }
    ///7
    printf("7) 3 chairs and 2 tables cost Tk. 700, while 5 chairs and 3 tables cost Tk. 1100.\n\tWhat is the cost of 2 chairs and 2 tables?\n");
    printf("\t1.Tk. 350\n");
    printf("\t2.Tk. 600\n");
    printf("\t3.Tk. 450\n");
    printf("\t4.Tk. 300\n");
    printf("Choose:");
    scanf("%d", &ch);
    if(ch>4 || ch<1)
    {
        printf("Wrong Input..!!\nChoose:");
        scanf("%d", &ch);
        if(ch==2)
        {
            printf("Correct Answer");
            m= m +10;
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is Tk. 600");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }
    else
    {
        if(ch==2)
        {
            printf("Correct Answer");
            m= m +10;
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is Tk. 600");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }
    ///8

    printf("8) The product of two consecutive positive integers is 12 more then 12 times the sum of those two integers.\n\tWhat is the smaller of the two integers?\n");
    printf("\t1. 24\n");
    printf("\t2. 20\n");
    printf("\t3. 21\n");
    printf("\t4. 25\n");
    printf("Choose:");
    scanf("%d", &ch);
    if(ch>4 || ch<1)
    {
        printf("Wrong Input..!!\nChoose:");
        scanf("%d", &ch);
        if(ch==1)
        {
            printf("Correct Answer");
            m= m +10;
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is 24");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }
    else
    {
        if(ch==1)
        {
            printf("Correct Answer");
            m= m +10;
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is 24");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }
    ///9

    printf("9) Two numbers x, y. Their sum is 100 and difference is 50.Find the numbers?\n");
    printf("\t1. 75 & 25\n");
    printf("\t2. 65 & 35\n");
    printf("\t3. 50 & 20\n");
    printf("\t4. 60 & 10\n");
    printf("Choose:");
    scanf("%d", &ch);
    if(ch>4 || ch<1)
    {
        printf("Wrong Input..!!\nChoose:");
        scanf("%d", &ch);
        if(ch==1)
        {
            printf("Correct Answer");
            m= m +10;
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is 75 & 25");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }
    else
    {
        if(ch==1)
        {
            printf("Correct Answer");
            m= m +10;
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is 75 & 25");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }
    ///10

    printf("10) Here,\n\t2x - y = 30\n\tx - y = 10.Find x,y?\n");
    printf("\t1. x=10 & y=20\n");
    printf("\t2. x=30 & y=15\n");
    printf("\t3. x=20 & y=10\n");
    printf("\t4. x=15 & y=30\n");
    printf("Choose:");
    scanf("%d", &ch);
    if(ch>4 || ch<1)
    {
        printf("Wrong Input..!!\nChoose:");
        scanf("%d", &ch);
        if(ch==3)
        {
            printf("Correct Answer");
            m= m +10;
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is x=20 & y=10");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }
    else
    {
        if(ch==3)
        {
            printf("Correct Answer");
            m= m +10;
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is x=20 & y=10");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }
    ///report
    if(m==100)
    {
        printf("Your Score is %d\nCongrates.\nYou got full Marks\n",m);
        printf("Report: Excellent");
    }
    else if(m>=80 && m<=99)
    {
        printf("Your Score is %d\nReport: Very Good",m);
    }

    else if(m>=70 && m<=79)
    {
        printf("Your Score is %d\nReport: Good",m);
    }
    else if(m>=55 && m<=69)
    {
        printf("Your Score is %d\nReport: Average Marks\nTry better Next Time",m);
    }
    else if(m<55)
    {
        printf("Your Score is %d\nYou Failed\nTry Again",m);
    }
    printf("\n");
    system("pause");
    system("cls");

    main();

}


void c_prog()
{
    int ch,m=0;

    printf("\nTopic: C Programming\nLet's Start\n");
    system("pause");
    system("cls");
    ///1
    printf("1) x=10. Find x++\n");
    printf("\t1. 12\n");
    printf("\t2. 11\n");
    printf("\t3. 10\n");
    printf("\t4. 9\n");
    printf("Choose:");
    scanf("%d", &ch);
    if(ch>4 || ch<1)
    {
        printf("Wrong Input..!!\nChoose:");
        scanf("%d", &ch);
        if(ch==2)
        {
            printf("Correct Answer");
            m= m +10;
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is 11");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }
    else
    {
        if(ch==2)
        {
            printf("Correct Answer");
            m= m +10;
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is 11");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }

    ///2
    printf("2) What is the binary digit of 14 in 4-bits?\n");
    printf("\t1. 1010\n");
    printf("\t2. 1001\n");
    printf("\t3. 1110\n");
    printf("\t4. 0111\n");
    printf("Choose:");
    scanf("%d", &ch);
    if(ch>4 || ch<1)
    {
        printf("Wrong Input..!!\nChoose:");
        scanf("%d", &ch);
        if(ch==3)
        {
            printf("Correct Answer");
            m= m +10;
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is 1110");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }
    else
    {
        if(ch==3)
        {
            printf("Correct Answer");
            m= m +10;
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is 1110");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }

    ///3
    printf("3) Which of the follow in 'AND' operator?\n");
    printf("\t1. ||\n");
    printf("\t2. &\n");
    printf("\t3. |\n");
    printf("\t4. &&\n");
    printf("Choose:");
    scanf("%d", &ch);
    if(ch>4 || ch<1)
    {
        printf("Wrong Input..!!\nChoose:");
        scanf("%d", &ch);
        if(ch==4)
        {
            printf("Correct Answer");
            m= m +10;
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is 4");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }
    else
    {
        if(ch==4)
        {
            printf("Correct Answer");
            m= m +10;
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is 4");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }

    ///4
    printf("4) Which function is main()?\n");
    printf("\t1.User defined Function\n");
    printf("\t2.Standard Function\n");
    printf("\t3.Library Function\n");
    printf("\t4.Function Prototype\n");
    printf("Choose:");
    scanf("%d", &ch);
    if(ch>4 || ch<1)
    {
        printf("Wrong Input..!!\nChoose:");
        scanf("%d", &ch);
        if(ch==1)
        {
            printf("Correct Answer");
            m= m +10;
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is User Defined Function");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }
    else
    {
        if(ch==1)
        {
            printf("Correct Answer");
            m= m +10;
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is User Defined Function");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }
    ///5

    printf("5) Which one does the input in C Programming?\n");
    printf("\t1. printf()\n");
    printf("\t2. main()\n");
    printf("\t3. input()\n");
    printf("\t4. scanf()\n");
    printf("Choose:");
    scanf("%d", &ch);
    if(ch>4 || ch<1)
    {
        printf("Wrong Input..!!\nChoose:");
        scanf("%d", &ch);
        if(ch==4)
        {
            printf("Correct Answer");
            m= m +10;
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is scanf()");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }
    else
    {
        if(ch==4)
        {
            printf("Correct Answer");
            m= m +10;
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is scanf()");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }
    ///6

    printf("6) What will be the input/output for 'int' keyword?\n");
    printf("\t1.Integer\n");
    printf("\t2.Decimal\n");
    printf("\t3.Fractions\n");
    printf("\t4.None\n");
    printf("Choose:");
    scanf("%d", &ch);
    if(ch>4 || ch<1)
    {
        printf("Wrong Input..!!\nChoose:");
        scanf("%d", &ch);
        if(ch==1)
        {
            printf("Correct Answer");
            m= m +10;
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is Integer");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }
    else
    {
        if(ch==1)
        {
            printf("Correct Answer");
            m= m +10;
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is Integer");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }

    ///7
    printf("7) Which of the following is datatype?\n");
    printf("\t1.char\n");
    printf("\t2.int\n");
    printf("\t3.float\n");
    printf("\t4.All in above\n");
    printf("Choose:");
    scanf("%d", &ch);
    if(ch>4 || ch<1)
    {
        printf("Wrong Input..!!\nChoose:");
        scanf("%d", &ch);
        if(ch==4)
        {
            printf("Correct Answer");
            m= m +10;
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is All in above");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }
    else
    {
        if(ch==4)
        {
            printf("Correct Answer");
            m= m +10;
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is All in above");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }
    ///8
    printf("8) What is the ASCII value of 'A'?\n");
    printf("\t1. 97\n");
    printf("\t2. 65\n");
    printf("\t3. 32\n");
    printf("\t4. 79\n");
    printf("Choose:");
    scanf("%d", &ch);
    if(ch>4 || ch<1)
    {
        printf("Wrong Input..!!\nChoose:");
        scanf("%d", &ch);
        if(ch==1)
        {
            printf("Correct Answer");
            m= m +10;
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is 97");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }
    else
    {
        if(ch==1)
        {
            printf("Correct Answer");
            m= m +10;
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is 97");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }

    ///9
    printf("9) What is the binary representation of x in x = 4+7?\n");
    printf("\t1.1001\n");
    printf("\t2.1000\n");
    printf("\t3.1111\n");
    printf("\t4.1011\n");
    printf("Choose:");
    scanf("%d", &ch);
    if(ch>4 || ch<1)
    {
        printf("Wrong Input..!!\nChoose:");
        scanf("%d", &ch);
        if(ch==4)
        {
            printf("Correct Answer");
            m= m +10;
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is 1011");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }
    else
    {
        if(ch==4)
        {
            printf("Correct Answer");
            m= m +10;
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is 1011");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }
    ///10
    printf("10) What is the value of integer 'a' without assigning any value?\n");
    printf("\t1. Junk value\n");
    printf("\t2. 11111\n");
    printf("\t3. 00000\n");
    printf("\t4. None\n");
    printf("Choose:");
    scanf("%d", &ch);
    if(ch>4 || ch<1)
    {
        printf("Wrong Input..!!\nChoose:");
        scanf("%d", &ch);
        if(ch==1)
        {
            printf("Correct Answer");
            m= m +10;
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is Junk value");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }
    else
    {
        if(ch==1)
        {
            printf("Correct Answer");
            m= m +10;
        }
        else
        {
            m= m-5;
            printf("Wrong Answer.\nAnswer is Junk value");
        }

        printf("\nYou Current Score is %d\n", m);
        system("pause");
        system("cls");
    }
///report
    if(m==100)
    {
        printf("Your Score is %d\nCongrates.\nYou got full Marks\n",m);
        printf("Report: Excellent");
    }
    else if(m>=80 && m<=99)
    {
        printf("Your Score is %d\nReport: Very Good",m);
    }

    else if(m>=70 && m<=79)
    {
        printf("Your Score is %d\nReport: Good",m);
    }
    else if(m>=55 && m<=69)
    {
        printf("Your Score is %d\nReport: Average Marks\nTry better Next Time",m);
    }
    else if(m<55)
    {
        printf("Your Score is %d\nYou Failed\nTry Again",m);
    }

    printf("\n");
    system("pause");
    system("cls");

    main();
}


void details()
{
    system("cls");
    printf("This is MULTIPLE CHOICE QUESTION game.\nThere are 3 Topics and each topic has 10 questions.\nFor every correct answer you will be rewarded with 10 points\nAgain for any wrong answer Your point will be deducted by 5\n");
    printf("Minimum score to pass is 55\n");
    printf("Hope you will enjoy it.");
    printf("\n\n");


    system("pause");
    system("cls");

    main();
}
